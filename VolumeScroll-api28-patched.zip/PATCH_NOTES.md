# VolumeScroll — Android 9 (Pie, API 28) port patch

This is a patched copy of [VolumeScroll](https://github.com/YeapGuy/VolumeScroll)
(upstream version 1.0.2, commit state at time of patch) modified to install and
run on Android 9.0 Pie (API 28) in addition to Android 10+.

## Why this works

The app's core mechanism — intercepting volume keys through an Accessibility
Service (`AccessibilityService.onKeyEvent()` with
`FLAG_REQUEST_FILTER_KEY_EVENTS` / `canRequestFilterKeyEvents`) — was
introduced in **API 28 (Android 9.0)**. Pie is therefore the oldest Android
version the app can ever support; below API 28 the interception API does not
exist. Every other API the app relies on predates Android 9:

| API used | Since |
|---|---|
| `dispatchGesture()` / `GestureDescription` (smooth scroll) | API 24 |
| `VibrationEffect` (toggle feedback) | API 26 |
| `WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY` (overlay toast) | API 22 |
| `TileService` Quick Settings tile | API 24 |
| Material 3 widgets (`MaterialSwitch`, `Slider`, `MaterialAlertDialogBuilder`) | library (API 21+) |
| `DynamicColors.applyToActivitiesIfAvailable()` | self-guards; no-op below API 31 |
| `VibratorManager` (API 31) | already guarded upstream by `SDK_INT >= S` |

## What was changed

Three changes, all marked with `// Patched:` comments in the code:

1. **`app/build.gradle.kts`**
   - `minSdk = 29` -> `minSdk = 28`
   - `versionCode = 3` -> `versionCode = 4`
   - `versionName = "1.0.2"` -> `versionName = "1.0.2-pie"`

2. **`app/src/main/java/com/yeapguy/volumescroll/VolumeScrollTileService.java`**
   - Added `import android.os.Build;`
   - Wrapped the single `Tile.setSubtitle(...)` call in
     `if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)`. `setSubtitle()`
     was added in API 29; calling it unconditionally on an Android 9 device
     would throw `NoSuchMethodError` every time the tile updates. Android 9's
     Quick Settings never rendered tile subtitles, so nothing is lost.

3. **`PATCH_NOTES.md`** (this file) added.

No other source files were modified. Nothing in the app's behavior changes on
Android 10+ devices.

## Behavior on Android 9

- Volume-button scrolling, scroll amount, invert direction, dual-volume-button
  toggle, app filter and the overlay feedback all work identically.
- The Quick Settings tile shows state via active/inactive icon color; the
  on/off subtitle line is simply omitted (as on all pre-Android-10 tiles).

## Build

Toolchain unchanged from upstream: Gradle 9.3.1, Android Gradle Plugin 9.1.0,
`compileSdk` 36.1, JDK 17 (upstream CI uses Temurin 17). Note the upstream
README says "JDK 11+", but AGP 9.x actually requires JDK 17 or newer.

```bash
./gradlew :app:assembleDebug
```

If your build environment cannot run AGP 9.x, you can downgrade without any
runtime effect: use Android Gradle Plugin 8.x and replace the
`compileSdk { version = release(36) { minorApiLevel = 1 } }` block with plain
`compileSdk = 35` (or 34). That only affects the build toolchain, not the APK's
behavior.

## License

MIT (same as upstream, see LICENSE).
